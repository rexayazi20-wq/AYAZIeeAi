# AYAZIeeAi Android

Native Android starter app for AYAZIeeAi.

## Build
Open with Android Studio or use the included GitHub Actions workflow in your repository.

## Runtime requirements
- Android 8.0 (API 26) or newer.
- Internet connection for API-based chat.
- A compatible OpenAI-style Chat Completions endpoint and your own API key.
- Voice typing uses the speech recognition service installed on the device.

## Configure
Launch the app, tap SETTINGS, and enter:
- Endpoint (default: https://api.openai.com/v1/chat/completions)
- Model (default: gpt-4o-mini)
- Your API key

The API key and local conversation history are stored in app-private SharedPreferences. This is an online API client, not an offline language model or autonomous agent.
