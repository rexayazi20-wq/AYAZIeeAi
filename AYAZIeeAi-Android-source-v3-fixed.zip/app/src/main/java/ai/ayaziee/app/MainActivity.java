package ai.ayaziee.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int VOICE_REQUEST = 41;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ArrayList<JSONObject> history = new ArrayList<>();
    private SharedPreferences prefs;
    private LinearLayout messages;
    private ScrollView scroll;
    private EditText composer;
    private TextView status;
    private String endpoint;
    private String model;
    private String apiKey;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("ayazieeai", MODE_PRIVATE);
        endpoint = prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions");
        model = prefs.getString("model", "gpt-4o-mini");
        apiKey = prefs.getString("apiKey", "");
        buildUi();
        loadHistory();
        if (history.isEmpty()) {
            addBubble("AYAZIeeAi online. Configure your API key in Settings to start chatting.", false);
        }
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(12));
        root.setBackgroundColor(Color.rgb(9, 12, 18));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("AYAZIeeAi");
        title.setTextColor(Color.rgb(110, 245, 190));
        title.setTextSize(23);
        title.setTypeface(null, 1);
        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL AI // CHAOS MODE");
        subtitle.setTextColor(Color.rgb(139, 153, 171));
        subtitle.setTextSize(10);
        brand.addView(title);
        brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        Button settings = button("SETTINGS");
        settings.setOnClickListener(v -> showSettings());
        header.addView(settings);
        root.addView(header);

        status = new TextView(this);
        status.setText("● LOCAL INTERFACE READY");
        status.setTextColor(Color.rgb(110, 245, 190));
        status.setTextSize(10);
        status.setPadding(0, dp(12), 0, dp(8));
        root.addView(status);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(0, dp(6), 0, dp(12));
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);

        composer = new EditText(this);
        composer.setSingleLine(false);
        composer.setMinLines(1);
        composer.setMaxLines(4);
        composer.setTextSize(15);
        composer.setTextColor(Color.WHITE);
        composer.setHintTextColor(Color.rgb(120, 132, 148));
        composer.setHint("Message AYAZIeeAi...");
        composer.setPadding(dp(14), dp(10), dp(14), dp(10));
        composer.setBackground(rounded(Color.rgb(27, 34, 46), 18));
        inputRow.addView(composer, new LinearLayout.LayoutParams(0, -2, 1));

        Button voice = button("MIC");
        voice.setOnClickListener(v -> startVoice());
        inputRow.addView(voice);

        Button send = button("SEND");
        send.setOnClickListener(v -> sendMessage());
        inputRow.addView(send);
        root.addView(inputRow);
        setContentView(root);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setTextColor(Color.rgb(110, 245, 190));
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(rounded(Color.rgb(27, 42, 48), 14));
        return b;
    }

    private void addBubble(String text, boolean user) {
        TextView bubble = new TextView(this);
        bubble.setText(text);
        bubble.setTextSize(15);
        bubble.setTextColor(user ? Color.WHITE : Color.rgb(220, 231, 240));
        bubble.setPadding(dp(14), dp(11), dp(14), dp(11));
        bubble.setBackground(rounded(user ? Color.rgb(35, 73, 70) : Color.rgb(25, 32, 43), 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                user ? (int)(getResources().getDisplayMetrics().widthPixels * 0.78f) : -1, -2);
        lp.gravity = user ? Gravity.RIGHT : Gravity.LEFT;
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(6);
        messages.addView(bubble, lp);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void loadHistory() {
        try {
            JSONArray saved = new JSONArray(prefs.getString("history", "[]"));
            for (int i = 0; i < saved.length(); i++) {
                JSONObject item = saved.getJSONObject(i);
                history.add(item);
                addBubble(item.optString("content"), "user".equals(item.optString("role")));
            }
        } catch (Exception ignored) { }
    }

    private void saveHistory() {
        JSONArray array = new JSONArray();
        int start = Math.max(0, history.size() - 40);
        for (int i = start; i < history.size(); i++) array.put(history.get(i));
        prefs.edit().putString("history", array.toString()).apply();
    }

    private void sendMessage() {
        String text = composer.getText().toString().trim();
        if (text.isEmpty()) return;
        composer.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(composer.getWindowToken(), 0);
        addBubble(text, true);
        try {
            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("content", text);
            history.add(user);
            saveHistory();
        } catch (Exception ignored) { }

        if (apiKey.trim().isEmpty()) {
            addBubble("Open SETTINGS and add your API key first. The key is stored on this device.", false);
            return;
        }
        status.setText("● THINKING...");
        worker.execute(() -> {
            try {
                String answer = requestAi();
                runOnUiThread(() -> {
                    status.setText("● ONLINE");
                    addBubble(answer, false);
                    try {
                        JSONObject assistant = new JSONObject();
                        assistant.put("role", "assistant");
                        assistant.put("content", answer);
                        history.add(assistant);
                        saveHistory();
                    } catch (Exception ignored) { }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    status.setText("● CONNECTION ERROR");
                    addBubble("Request failed: " + e.getMessage(), false);
                });
            }
        });
    }

    private String requestAi() throws Exception {
        URL url = new URL(endpoint);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(45000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Authorization", "Bearer " + apiKey);

        JSONObject body = new JSONObject();
        body.put("model", model);
        JSONArray messagesJson = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", "You are AYAZIeeAi, a clever, energetic personal assistant with a playful chaotic personality. Be useful, direct, and honest.");
        messagesJson.put(system);
        int start = Math.max(0, history.size() - 16);
        for (int i = start; i < history.size(); i++) messagesJson.put(history.get(i));
        body.put("messages", messagesJson);

        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream out = connection.getOutputStream()) { out.write(payload); }

        int code = connection.getResponseCode();
        InputStream stream = code >= 200 && code < 300
                ? connection.getInputStream() : connection.getErrorStream();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[4096];
        int n;
        while ((n = stream.read(chunk)) != -1) buffer.write(chunk, 0, n);
        stream.close();
        String response = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
        connection.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + response);
        JSONObject result = new JSONObject(response);
        return result.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content");
    }

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setPadding(dp(20), dp(8), dp(20), dp(8));
        panel.setOrientation(LinearLayout.VERTICAL);

        EditText endpointInput = new EditText(this);
        endpointInput.setSingleLine(true);
        endpointInput.setText(endpoint);
        endpointInput.setHint("API endpoint URL");
        panel.addView(endpointInput);

        EditText modelInput = new EditText(this);
        modelInput.setSingleLine(true);
        modelInput.setText(model);
        modelInput.setHint("Model name");
        panel.addView(modelInput);

        EditText keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("API key");
        keyInput.setText(apiKey);
        panel.addView(keyInput);

        new AlertDialog.Builder(this)
                .setTitle("AYAZIeeAi Settings")
                .setView(panel)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("SAVE", (dialog, which) -> {
                    endpoint = endpointInput.getText().toString().trim();
                    model = modelInput.getText().toString().trim();
                    apiKey = keyInput.getText().toString().trim();
                    if (endpoint.isEmpty()) endpoint = "https://api.openai.com/v1/chat/completions";
                    if (model.isEmpty()) model = "gpt-4o-mini";
                    prefs.edit().putString("endpoint", endpoint)
                            .putString("model", model).putString("apiKey", apiKey).apply();
                    status.setText("● SETTINGS SAVED");
                }).show();
    }

    private void startVoice() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AYAZIeeAi");
            startActivityForResult(intent, VOICE_REQUEST);
        } catch (Exception e) {
            addBubble("Voice input is not available on this device.", false);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VOICE_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) composer.setText(results.get(0));
        }
    }

    @Override
    protected void onDestroy() {
        worker.shutdown();
        super.onDestroy();
    }
}
